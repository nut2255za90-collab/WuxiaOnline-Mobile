WUXIA ONLINE MOBILE — Android APK project starter

สิ่งที่มีในโปรเจกต์
- Android app shell (Java + WebView)
- เกมเดโม 3D ใน assets/index.html พร้อม EXP, เลเวลอัป และบันทึกเลเวล/เงินในเครื่อง
- ปุ่มสัมผัส เดิน/โจมตี/สกิล และฉากแฟนตาซี

ข้อจำกัดสำคัญ
- นี่คือซอร์สโปรเจกต์สำหรับสร้าง APK ยังไม่ใช่ไฟล์ APK ที่คอมไพล์แล้ว
- ฉาก 3D ใช้ Three.js จาก CDN จึงต้องเชื่อมต่ออินเทอร์เน็ตขณะเล่น
- เป็นเดโมเล่นคนเดียว ยังไม่มีเซิร์ฟเวอร์ MMORPG, ระบบบัญชี, PvP หรือบันทึกความคืบหน้าแบบคลาวด์; การบันทึกเลเวล/เงินเป็นแบบในเครื่องเท่านั้น

วิธีสร้าง APK
1. แตก ZIP บนคอมพิวเตอร์
2. ติดตั้ง Android Studio รุ่นปัจจุบัน พร้อม Android SDK Platform 35
3. เปิดโฟลเดอร์ WuxiaOnline_Mobile_APK_Project ใน Android Studio
4. รอ Gradle Sync เสร็จ
5. เลือก Build > Build Bundle(s) / APK(s) > Build APK(s)
6. APK สำหรับทดสอบจะอยู่ใน app/build/outputs/apk/debug/app-debug.apk

แนะนำให้ทดสอบบนโทรศัพท์จริงก่อนเผยแพร่ และต้องเชื่อมต่ออินเทอร์เน็ตสำหรับโหลด Three.js
